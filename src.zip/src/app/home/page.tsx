'use client';

import { useRouter } from 'next/navigation';
import { signOut } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { useState } from "react";

import LoadingMessage from "@/components/LoadingMessage";
import PrimaryButton from "@/components/PrimaryButton";
import FooterNav from '@/components/FooterNav';
import DailyChallengeModal from '@/components/DailyChallengeModal';
import { useAuthGuard } from "@/hooks/useAuthGuard";


export default function HomePage() {
    const router = useRouter();
    const { user, loading } = useAuthGuard({ requireLogin: true });
    const [open, setOpen] = useState(false);


    if (loading) return <LoadingMessage />;

    const handleLogout = async () => {
        await signOut(auth);
        localStorage.removeItem('authUser');
        router.push('/login');
    };

    return (
        <div className="flex flex-col items-center justify-center h-screen space-y-6">
            <h1 className="text-2xl font-bold">ホーム</h1>
            <p>こんにちは、{user?.username} さん</p>

            <div className="flex space-x-4">
                <PrimaryButton
                    text="記録ページへ"
                    onClick={() => router.push('/record')}
                    color="green"
                />

                <button
                    onClick={() => setOpen(true)}
                    style={{
                        padding: "10px 14px", borderRadius: 10, border: "1px solid #d1d5db",
                        background: "#fff", width: "fit-content", cursor: "pointer"
                    }}
                >
                    デイリーチャレンジを開く
                </button>
                <DailyChallengeModal
                    open={open}
                    onClose={() => setOpen(false)}
                    onGoFeed={() => {/* ご飯画面へ */ }}
                    onGoOmikuji={() => {/* おみくじ画面へ */ }}
                    onGoRecord={() => router.push('/record')}
                    state={{ completed: { feed: false, omikuji: true, record: false } }}
                />
                <PrimaryButton
                    text="記録一覧ページへ"
                    onClick={() => router.push('/list')}
                    color="green"
                />
                <PrimaryButton
                    text="ログアウト"
                    onClick={handleLogout}
                    color="red"
                />
            </div>
            <FooterNav />
        </div>
    );
}
